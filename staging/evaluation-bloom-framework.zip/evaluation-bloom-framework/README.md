# Evaluation to Growth Skill - Structure & Contents

## Overview

A comprehensive skill package implementing the **Evaluation to Growth** framework—a systematic methodology for rigorous multi-dimensional content assessment and iterative refinement.

**Skill Name**: `evaluation-to-growth`

## Directory Structure

```
evaluation-to-growth-skill/
├── SKILL.md                              [Main skill documentation]
└── references/
    ├── phase-prompts.md                  [Detailed phase guidance]
    ├── evaluation-patterns.md            [Discipline-specific patterns]
    └── output-templates.md               [Format examples]
```

### SKILL.md (189 lines)
**Primary entry point** - Contains:
- YAML frontmatter (name, description)
- Core methodology overview (4 phases)
- Phase summary and objectives
- Mode selection (Interactive vs. Autonomous)
- Output format selection (Markdown Report, Checklist, Inline Revisions)
- Detailed usage instructions
- Common workflows for different content types
- Key principles and framework flexibility

**When loaded**: After skill triggers
**Context window impact**: ~4 KB

### references/phase-prompts.md (563 lines)
**Detailed operational guidance** - Contains:
- Specific prompts for each phase (Critique, Logic Check, Logos, Pathos, Ethos, Blind Spots, Shatter Points, Bloom, Evolve)
- Expected output structures for each phase
- Example outputs showing real-world applications
- Content-type specific considerations (Research Papers, Proposals, Technical Docs, etc.)
- Clarifies what to look for in each phase

**When to load**: When executing a phase or needing specific prompts
**Context window impact**: ~18 KB

### references/evaluation-patterns.md (376 lines)
**Domain and content-type expertise** - Contains:
- Discipline-specific evaluation patterns (STEM, Humanities, Professional/Business, Creative/Arts)
- Academic contexts (Journal articles, Dissertations, Grants, Literature reviews)
- Professional contexts (Business plans, Policy documents, Marketing materials)
- Creative contexts (Fiction, Poetry, Visual art)
- Technical contexts (Code, Documentation, Instructional content)
- Cross-cutting patterns (Evidence hierarchies, Audience alignment, Credibility signals)
- Framework customization by discipline

**When to load**: When evaluating content in specific domain
**Context window impact**: ~12 KB

### references/output-templates.md (598 lines)
**Output format specifications** - Contains:
- Markdown Report template (comprehensive documentation)
- Structured Checklist template (progress tracking)
- Inline Revisions template (direct editing workflow)
- Examples of each format type
- Format selection guide
- Hybrid approach suggestions
- Customization tips by content type

**When to load**: When preparing output or deciding on format
**Context window impact**: ~19 KB

## Total Content Scope

| Component | Lines | Purpose |
|-----------|-------|---------|
| SKILL.md | 189 | Framework overview & usage |
| phase-prompts.md | 563 | Operational guidance per phase |
| evaluation-patterns.md | 376 | Domain-specific expertise |
| output-templates.md | 598 | Output format specifications |
| **Total** | **1,726** | Complete skill package |

## How the Skill Works

### 1. **Trigger**
Skill activates when user:
- Asks to evaluate, critique, improve, strengthen, or review content
- Requests systematic assessment of writing, arguments, proposals, code, creative work, etc.
- Seeks feedback using structured framework

Metadata description triggers activation (loaded immediately, ~100 words).

### 2. **Execution**
SKILL.md loads (189 lines), providing:
- Framework overview
- Mode and format selection guidance
- High-level phase descriptions
- Usage workflow

### 3. **Phase Guidance**
As phases execute, Claude references:
- **phase-prompts.md**: For specific prompts and output structures
- **evaluation-patterns.md**: For domain/content-type specific considerations
- **output-templates.md**: For formatting the final deliverable

These are loaded on-demand based on content type and phase requirements.

### 4. **Output Delivery**
Final evaluation provided in selected format:
- **Markdown Report**: Comprehensive documentation (~2-5 KB per evaluation)
- **Structured Checklist**: Trackable action items (~1-2 KB)
- **Inline Revisions**: Annotated original with suggestions (~varies with content size)

## Integration Points

### For Collaborative Workflows
1. User provides content + context
2. Claude executes framework (Interactive or Autonomous mode)
3. Skill delivers structured output (Checklist format recommended for team tracking)
4. Team implements recommendations
5. Return to step 2 for second-pass evaluation (if needed)

### For Academic/Publication Workflows
1. Author provides draft + target journal/conference
2. Claude evaluates with academic patterns (from evaluation-patterns.md)
3. Delivers Markdown Report with comprehensive feedback
4. Author revises based on recommendations
5. Return for second-pass or publication readiness check

### For Creative Development
1. Artist/Writer provides work + intended audience
2. Claude executes Interactive mode for collaborative refinement
3. Output as Inline Revisions for contextual feedback
4. Integrate improvements and iterate
5. Use Bloom phase insights for expansion opportunities

## Framework Philosophy

The skill codifies the **Evaluation to Growth** methodology:

```
[Evaluation] → [Reinforcement] → [Risk Analysis] → [Growth]
```

**Not just critique** - extends from problem identification (Critique, Logic Check, Logos, Pathos, Ethos) through risk mitigation (Blind Spots, Shatter Points) to opportunity generation (Bloom, Evolve).

**Flexible by discipline** - patterns documented for STEM, Humanities, Professional, Creative, and Technical domains with explicit customization guidance.

**Multiple iterations** - designed for repeated passes; improvements compound across iterations.

## Key Features

✓ **Comprehensive**: 5-dimensional evaluation framework with 9 distinct phases
✓ **Flexible**: Interactive/Autonomous modes, 3 output formats, discipline customization
✓ **Actionable**: Specific prompts, structured outputs, implementation tracking
✓ **Scalable**: From brief documents to book-length manuscripts
✓ **Academic-ready**: Supports publication prep, peer review response, grant writing
✓ **Production-focused**: Practical patterns for real-world professional use

## Usage Recommendations

### First-Time Users
1. Read SKILL.md introduction completely
2. Choose Interactive mode for first evaluation
3. After phase 1, select output format that matches your workflow
4. Refer to phase-prompts.md as each phase executes
5. Review output-templates.md to see example deliverables

### Returning Users
1. Select mode (Interactive or Autonomous) upfront
2. Provide context (audience, objectives, success criteria)
3. Specify output format
4. Reference evaluation-patterns.md only if content is in unfamiliar domain
5. Iterate: Second pass typically yields 30-40% additional improvements

### For Specific Domains
- **Academic research**: See evaluation-patterns.md "Academic and Scholarly Work"
- **Professional/Business**: See evaluation-patterns.md "Professional and Business Documents"
- **Creative work**: See evaluation-patterns.md "Creative and Artistic Work"
- **Technical/Code**: See evaluation-patterns.md "Technical and Instructional Content"

## Customization

The skill is modular and can be extended:

- Add discipline-specific patterns to evaluation-patterns.md
- Create template variations in output-templates.md for specific workflows
- Develop hybrid processes combining multiple phases based on content type
- Adapt phase prompts in phase-prompts.md for specialized contexts

## Context Window Efficiency

Progressive disclosure design minimizes context bloat:

1. **Always in context** (~100 words): Skill name and description
2. **On skill trigger** (~4 KB): SKILL.md body
3. **As needed** (~12-19 KB each): Reference files

**Typical evaluation impact**: 4-8 KB on context window per use
**Comprehensive evaluation with all references**: ~30-40 KB

Efficient design allows skill to work alongside other tools and capabilities.

## Compatibility

- **Target**: All Claude users and versions
- **No external dependencies**: Framework is self-contained
- **Works with**: Any content type (text, code, proposals, creative work, etc.)
- **Integrates with**: File editing tools, presentation creation, documentation systems

---

## Quick Start

```
User: "I need to evaluate my research paper draft before submission"

Claude:
1. Activates evaluation-to-growth skill
2. Asks: "Would you like interactive or autonomous evaluation?"
3. Asks: "Which output format? Markdown Report, Checklist, or Inline Revisions?"
4. Executes all 4 phases with academic-focused patterns
5. Delivers comprehensive evaluation in selected format
```

Complete evaluation typically takes 5-15 minutes depending on content length and mode.
