---
name: evaluation-to-growth
description: Systematic content evaluation framework for rigorous multi-dimensional assessment. Use when reviewing, critiquing, improving, or strengthening any content including writing, arguments, proposals, research papers, code documentation, creative work, or presentations. Provides structured pathways through Critique → Reinforcement → Risk Analysis → Growth phases. Supports interactive guided mode or autonomous full-report mode with output as markdown report, structured checklist, or inline revisions.
---

# Evaluation to Growth Framework

A systematic methodology for transforming content through rigorous evaluation into stronger, more resilient final products.

## Core Methodology

The framework progresses through four phases:

```
[Evaluation] → [Reinforcement] → [Risk Analysis] → [Growth]
```

Each phase builds on previous findings, creating a complete assessment pipeline from initial critique through final iteration.

## Phase Overview

### Evaluation Phase
Comprehensive assessment across five distinct dimensions:

- **Critique**: Identify strengths and weaknesses holistically
- **Logic Check**: Ensure internal consistency and sound reasoning
- **Logos Review**: Assess rational and factual appeal
- **Pathos Review**: Evaluate emotional resonance and connection
- **Ethos Review**: Examine credibility, authority, and trustworthiness

**Desired Outcome**: Clear understanding of what works and what needs improvement

### Reinforcement Phase
Synthesis and coherence strengthening:

- Resolve identified contradictions
- Fill reasoning gaps
- Support or remove unsupported claims
- Strengthen transitional logic

**Desired Outcome**: Internally consistent, logically coherent content

### Risk Analysis Phase
Vulnerability identification and mitigation:

- **Blind Spots**: Reveal overlooked areas, biases, and hidden assumptions
- **Shatter Points**: Pinpoint critical vulnerabilities and potential breaking points

**Desired Outcome**: Reduced risk of missed issues or critical failures

### Growth Phase
Transform evaluation into evolution:

- **Bloom**: Generate emergent insights, new directions, and expansion opportunities
- **Evolve**: Produce polished, stronger, more resilient final version

**Desired Outcome**: Innovative directions and refined final product

## Mode Selection

Determine your workflow approach before beginning.

### Interactive Mode
Walk through each phase step-by-step with pauses for reflection and direction between stages.

**Best for**: Collaborative refinement, learning the framework, complex or high-stakes content

**Workflow**:
1. Execute current phase
2. Present findings with decision points
3. Pause for user input or direction
4. Proceed to next phase based on user guidance

### Autonomous Mode
Execute all phases and deliver comprehensive results without pauses.

**Best for**: Efficient batch evaluation, comprehensive upfront analysis, when user wants complete assessment

**Workflow**:
1. Execute all four phases sequentially
2. Synthesize findings across phases
3. Deliver complete analysis with recommendations

## Output Format Selection

### Markdown Report
Structured document with sections for each phase, findings, and actionable recommendations.

**Best for**: Documentation, sharing with stakeholders, publication readiness, formal records

**Structure**:
- Executive summary
- Phase-by-phase findings
- Risk assessment and mitigations
- Growth recommendations
- Revised content (if applicable)

### Structured Checklist
Itemized findings with status indicators, priority ratings, and action items.

**Best for**: Tracking implementation, agile workflows, quick reference, team coordination

**Structure**:
- Categorized findings
- Priority/severity levels
- Actionable items
- Progress tracking

### Inline Revisions
Suggestions embedded within or alongside original content with explanations.

**Best for**: Direct editing workflow, line-by-line improvement, transparent change documentation

**Structure**:
- Original text with annotations
- Suggested revisions with reasoning
- Alternative options when applicable

## Using the Framework

### Step 1: Select Mode and Format
Determine whether you want interactive or autonomous execution and choose your output format.

### Step 2: Provide Content
Share the content requiring evaluation. Can be any form: written text, code, proposals, research papers, presentations, arguments, documentation, creative work, etc.

### Step 3: Specify Context (Optional but Recommended)
Provide:
- Intended audience
- Primary objectives
- Success criteria
- Specific areas of concern
- Constraints or requirements

Clear context improves evaluation specificity and relevance.

### Step 4: Execute Framework
Proceed through selected mode. In interactive mode, engage with findings at each phase before moving forward.

### Step 5: Implement and Iterate
Use provided recommendations and revised content to strengthen your work. The framework supports multiple passes—evaluate refined versions for cumulative improvement.

## Detailed Phase Guidance

See `references/phase-prompts.md` for specific prompts, output structures, and example findings for each phase.

See `references/evaluation-patterns.md` for common patterns, frameworks, and considerations when evaluating different content types (research papers, proposals, creative work, code documentation, etc.).

## Common Workflows

### Academic Publication Preparation
1. **Mode**: Autonomous (comprehensive review)
2. **Format**: Markdown Report (formal documentation)
3. **Key phases**: Logos (argument structure), Ethos (credibility/sources), Blind Spots (methodological gaps)
4. **Iteration**: Minimum 2 passes through Evaluation phase recommended

### Creative Work Refinement
1. **Mode**: Interactive (collaborative development)
2. **Format**: Inline Revisions (direct feedback in context)
3. **Key phases**: Pathos (emotional impact), Blind Spots (audience assumptions), Bloom (expansion)
4. **Iteration**: Multiple passes, allowing for creative evolution

### Proposal or Argument Strengthening
1. **Mode**: Autonomous then Interactive (initial assessment, then targeted refinement)
2. **Format**: Structured Checklist (tracking implementation)
3. **Key phases**: Logic Check (coherence), Shatter Points (vulnerabilities), Evolve (final version)
4. **Iteration**: 2-3 passes recommended depending on complexity

### Documentation or Technical Writing
1. **Mode**: Interactive (clarity verification)
2. **Format**: Markdown Report (formal delivery)
3. **Key phases**: Logos (clarity/examples), Blind Spots (assumed knowledge), Ethos (authoritativeness)
4. **Iteration**: Single or double pass sufficient for technical content

## Key Principles

**Context is Outcome**: Richer context (intended audience, success criteria, constraints) produces more targeted and actionable evaluation. Invest time in specifying this upfront.

**Iteration Multiplies Value**: First pass identifies issues; second pass validates improvements and uncovers secondary concerns. High-stakes content benefits from multiple passes.

**Framework Flexibility**: Not all phases carry equal weight for all content types. Prioritize phases most relevant to your objectives while maintaining structural integrity.

**Growth Beyond Critique**: The framework extends beyond problem-identification into opportunity-generation (Bloom) and resilience-building (Evolve). Use this to move beyond mere correction into genuine improvement.

## References and Templates

- `references/phase-prompts.md` - Specific prompts, output structures, and example findings for each evaluation phase
- `references/evaluation-patterns.md` - Content-type specific patterns and considerations for different disciplines
- `references/output-templates.md` - Template examples for markdown reports, checklists, and inline revisions
