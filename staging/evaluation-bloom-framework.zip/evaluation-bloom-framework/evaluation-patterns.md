# Evaluation Patterns by Content Type

Discipline-specific and context-specific patterns, considerations, and priorities when using the Evaluation to Growth framework.

## Academic and Scholarly Work

### Journal Articles and Research Papers

**Framework Priority**:
1. **Logos** (70% weight) - Methodological soundness, evidence quality, argument validity
2. **Ethos** (15% weight) - Credibility, citation practices, positioning in literature
3. **Pathos** (10% weight) - Narrative coherence, reader engagement
4. **Logic Check** (100%) - Internal consistency critical
5. **Shatter Points** (100%) - Statistical validity and reproducibility must be bulletproof

**Key Blind Spots to Identify**:
- Methodological assumptions (generalizability, validity threats)
- Researcher bias (confirmation bias, selection bias)
- Missing or outdated citations in literature review
- Scope creep in claims (findings overgeneralized)
- Alternative explanations not discussed

**Critical Questions**:
- Are methods sufficiently detailed for independent reproduction?
- Do statistical claims match the statistical tests performed?
- Are limitations acknowledged and appropriate to study design?
- Is the literature review current (within last 5-7 years for most fields)?
- Do conclusion statements stay within scope of findings?

**Common Shatter Points**:
- Underpowered sample sizes affecting statistical validity
- Selection bias in participant recruitment
- Causation claims from correlational data
- Multiple comparison problems without correction
- Over-interpretation of non-significant findings

---

### Dissertations and Theses

**Special Considerations**:
- Evaluate against disciplinary standards (not general publishing standards)
- Committee fit: Does work address stated research questions comprehensively?
- Contribution clarity: Is original contribution to field clearly articulated?
- Feasibility: Is scope appropriate for thesis timeline and resources?

**Additional Focus Areas**:
- Problem statement clarity and significance to field
- Literature review adequacy and synthesis quality
- Methodological justification and rigor
- Results/findings presentation completeness
- Implications for future research clearly articulated

---

### Grant Proposals and Funding Applications

**Framework Priority**:
1. **Logos** (65%) - Feasibility, methodology, evidence for approach
2. **Ethos** (20%) - Team credibility, track record, institutional capacity
3. **Pathos** (10%) - Vision and significance compelling to funders
4. **Shatter Points** (100%) - Budget realism and timeline feasibility critical

**Key Vulnerabilities**:
- Timeline unrealistic relative to scope
- Budget doesn't align with proposed activities
- Key personnel lack relevant experience
- No preliminary data supporting proposed approach
- Evaluation metrics vague or unmeasurable
- Sustainability plan missing for non-renewable funding

**Audience-Specific Logos Elements**:
- If government funder: Alignment with stated priorities, compliance with requirements
- If private foundation: Fit with mission, demonstrated impact potential
- If corporate: ROI or business case articulation, market relevance

---

### Literature Reviews and Syntheses

**Special Focus**:
- Logos: Systematic methodology for selecting and synthesizing sources
- Organization: Thematic vs. chronological vs. methodological organization rationale
- Currency: Balance between foundational works and recent literature
- Gaps: Clear articulation of where literature is thin or conflicting

**Blind Spots**:
- Overrepresentation of certain theoretical perspectives
- Geographic or demographic bias in literature selection
- Publication bias (preference for significant findings)
- Missing non-English language publications
- Emerging perspectives not yet in peer-reviewed literature

---

## Professional and Business Documents

### Business Plans and Proposals

**Framework Priority**:
1. **Logos** (60%) - Feasibility, financial projections, market validation
2. **Ethos** (25%) - Team credibility, track record, capacity
3. **Pathos** (10%) - Vision compelling and inspiring
4. **Shatter Points** (100%) - Revenue model and key assumptions must withstand scrutiny

**Critical Vulnerabilities**:
- Revenue projections lack supporting data or comparable company metrics
- Competitive analysis superficial or ignoring key competitors
- Financial model lacks sensitivity analysis
- Key person dependency without succession planning
- Market size assertions unsupported by research

**Blind Spots to Identify**:
- Overconfidence in market adoption
- Underestimation of competition or market barriers
- Assumption of unchanging market conditions
- Overlooked regulatory or compliance requirements
- Underestimation of implementation timeline

---

### Policy Documents and White Papers

**Framework Priority**:
1. **Logos** (65%) - Evidence for problem and proposed solution
2. **Ethos** (20%) - Authority and credibility of recommendation
3. **Pathos** (10%) - Stakes and significance emotionally resonant
4. **Logic Check** (100%) - Internal consistency essential for policy credibility

**Key Shatter Points**:
- Problem magnitude/urgency claims unsupported
- Proposed solution lacks precedent or pilot data
- Unintended consequences not addressed
- Implementation feasibility unclear or unrealistic
- Cost-benefit analysis oversimplified

**Stakeholder-Specific Considerations**:
- Will affected populations see themselves in problem statement?
- Are concerns of skeptics/opposition preempted?
- Is language accessible to non-expert audiences?
- Are equity considerations integrated or addressed?

---

### Marketing and Communications Materials

**Framework Priority**:
1. **Pathos** (50%) - Emotional resonance and connection critical
2. **Ethos** (30%) - Trust and credibility establishment
3. **Logos** (15%) - Supporting facts and rationale
4. **Blind Spots** (100%) - Audience assumptions and representation must be verified

**Critical Blind Spots**:
- Assumptions about audience demographics or values
- Representation gaps or stereotypes
- Accessibility barriers (cognitive load, language level, format)
- Overlooked objections or customer concerns
- Cultural or contextual misalignment

**Tone and Voice Considerations**:
- Is brand voice consistent across messages?
- Does tone match audience expectations and values?
- Is voice authentic or does it ring hollow?
- Are claims defensible if challenged?

---

## Creative and Artistic Work

### Creative Writing (Fiction, Narrative)

**Framework Priority**:
1. **Pathos** (60%) - Emotional impact and reader engagement primary
2. **Logos** (25%) - Internal consistency of narrative logic and world-building
3. **Ethos** (10%) - Authenticity and credibility of voice
4. **Bloom** (100%) - Growth and evolution of narrative potential essential

**Special Evaluation Considerations**:
- Character consistency and development arc
- Plot logic and pacing
- Dialogue authenticity
- Narrative voice integrity
- Theme emergence and resonance
- Sensory detail and immersion quality

**Blind Spots Focus**:
- Unexamined assumptions about audience or culture
- Representation and authenticity concerns
- Emotional beats that don't land as intended
- Plot holes or internal inconsistencies
- Pacing issues (rushing or dragging)

---

### Poetry and Lyric Work

**Framework Priority**:
1. **Pathos** (70%) - Emotional precision and resonance
2. **Logos** (20%) - Internal coherence of image and metaphor
3. **Ethos** (5%) - Authenticity of voice
4. **Bloom** (100%) - Emergent meanings and reader discovery

**Specific Considerations**:
- Word choice precision and connotation
- Sound (rhythm, meter, assonance) effect on meaning
- Line breaks and white space function
- Image clarity and evocativeness
- Emotional arc within poem

**Evaluation Method**:
- Read aloud to assess sonic qualities
- Examine word choice for precision and emotional weight
- Trace metaphor coherence through poem
- Identify surprising or ineffective moments
- Test meaning openness (ambiguity vs. clarity balance)

---

### Visual and Multimedia Art

**Framework Adaptation**:
- Logos: Compositional coherence, technical execution
- Pathos: Emotional impact, visual resonance, viewer engagement
- Ethos: Authenticity of artistic voice, conceptual integrity
- Blind Spots: Viewer assumptions, cultural context, representation

**Evaluation Considerations**:
- Is conceptual intent conveyed visually?
- Does composition support intended meaning?
- Is execution technically sound for stated intention?
- Does work engage intended audience effectively?
- Are there unintended meanings or readings that might undermine intent?

---

## Technical and Instructional Content

### Code and Technical Documentation

**Framework Priority**:
1. **Logos** (70%) - Clarity, accuracy, completeness of technical content
2. **Ethos** (20%) - Authority and reliability, maintenance and versioning
3. **Blind Spots** (100%) - Assumed knowledge and accessibility critical
4. **Pathos** (5%) - Usability and approachability

**Key Documentation Blind Spots**:
- Assumed knowledge level inappropriate for target audience
- Accessibility barriers (code samples not executable, missing context)
- Gaps in explanation (steps assumed rather than stated)
- Missing error handling or common pitfalls
- Outdated examples or deprecated methods
- No indication of maintained status or version relevance

**Logos Checklist**:
- Are all concepts defined or linked to explanation?
- Are code examples correct and tested?
- Are edge cases and limitations documented?
- Is technical accuracy verifiable?
- Are standards or best practices followed?

---

### Instructional Content and Courses

**Framework Priority**:
1. **Logos** (60%) - Content accuracy, logical progression, completeness
2. **Pathos** (25%) - Engagement, pacing, motivation
3. **Ethos** (10%) - Credibility of instructor, learning environment safety
4. **Blind Spots** (100%) - Accessibility, diverse learning styles, prerequisite assumptions

**Bloom Focus**:
- Could this content be applied to adjacent domains?
- What skills emerge from mastering this material?
- How does this connect to broader learning goals?

**Learner-Specific Blind Spots**:
- Prerequisites not stated or verified
- Pacing too fast/slow for target level
- Examples not culturally or contextually relevant
- Accessibility barriers (visual, auditory, cognitive, motor)
- Implicit assumptions about student background or resources

---

## Common Evaluation Patterns Across All Types

### Evidence and Support Hierarchy

When evaluating Logos, assess evidence quality at these levels:

1. **Strongest**: Peer-reviewed empirical research, systematic reviews, meta-analyses
2. **Strong**: Published data from reputable institutions, direct experimentation
3. **Medium**: Case studies, expert testimony, documented precedent
4. **Weak**: Anecdote, assumption, analogy without support
5. **Absent**: Claim without any supporting evidence

Identify which level each major claim relies on and whether it's appropriate for the claim's strength.

---

### Audience Alignment Assessment

For any content, verify alignment with target audience:

**Demographic fit**:
- Age, education level, professional background appropriate?
- Language and complexity level appropriate?
- Examples and references relevant?

**Psychographic fit**:
- Values and concerns addressed?
- Tone and voice resonant?
- Assumed knowledge reasonable?

**Situational fit**:
- Use case and context clear?
- Practical applicability established?
- Time and attention investment justified?

---

### Credibility Signals Inventory

Evaluate what signals of credibility are present:

**Present**: Identify what establishes credibility (credentials, citations, track record, certifications, peer review status, organizational backing, etc.)

**Missing**: What would strengthen credibility if added?

**Contradictory**: What might undermine credibility if exposed (overstated claims, potential conflicts of interest, missing caveats, etc.)?

---

### Risk/Reward Matrix for Shatter Points

When identifying vulnerabilities, prioritize by impact:

```
HIGH IMPACT + HIGH PROBABILITY
→ Requires preventive measures and contingency planning

HIGH IMPACT + LOW PROBABILITY
→ Requires contingency planning and clear acknowledgment

LOW IMPACT + HIGH PROBABILITY
→ Requires minor corrections or clarifications

LOW IMPACT + LOW PROBABILITY
→ Nice to address but not critical
```

Focus risk analysis on high-impact vulnerabilities first.

---

## Framework Customization by Discipline

### STEM and Hard Sciences
- **Emphasize**: Logos (rigor), Logic Check (consistency), Shatter Points (validity)
- **Reduce**: Pathos (less weighted in traditional science communication)
- **Special focus**: Methodology, reproducibility, edge cases

### Humanities and Social Sciences
- **Emphasize**: Logos (evidence quality), Ethos (positioning in literature), Blind Spots (interpretation and bias)
- **Maintain**: Pathos (narrative coherence important)
- **Special focus**: Literature engagement, theoretical positioning, alternative perspectives

### Professional and Business
- **Emphasize**: Logos (feasibility), Ethos (credibility), Shatter Points (implementation risks)
- **Reduce**: Pathos (important but secondary to credibility and feasibility)
- **Special focus**: Feasibility, stakeholder confidence, risk acknowledgment

### Arts and Creative
- **Emphasize**: Pathos (impact), Logos (coherence), Bloom (evolution)
- **Reduce**: Ethos as authority (maintain as authenticity)
- **Special focus**: Audience resonance, internal coherence, growth potential
