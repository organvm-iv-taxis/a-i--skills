# Output Templates

Template examples and structures for three output formats: Markdown Report, Structured Checklist, and Inline Revisions.

---

## Markdown Report Template

Use this format for comprehensive documentation, sharing with stakeholders, or formal records.

```markdown
# Evaluation to Growth: Content Assessment Report

**Document Evaluated**: [Title/Description]
**Evaluation Date**: [Date]
**Evaluator**: [If applicable]
**Mode**: [Interactive/Autonomous]
**Intended Audience**: [If provided]
**Success Criteria**: [If provided]

---

## Executive Summary

[Paragraph summarizing key findings across all phases: primary strengths, 
critical vulnerabilities, major recommendations, and readiness for next phase.]

**Overall Assessment**: [Ready for publication / Needs revision before publication / 
Requires substantial development / etc.]

---

## 1. Evaluation Phase Findings

### 1.1 Critique

#### Strengths
- [Specific strength with reasoning]
- [Specific strength with reasoning]

#### Weaknesses
- [Specific weakness with reasoning]
- [Specific weakness with reasoning]

#### Priority Improvement Areas
1. [Highest priority with impact]
2. [Secondary priority]
3. [Tertiary priority]

### 1.2 Logic Check

#### Contradictions Identified
- [Contradiction with locations]
- [Contradiction with locations]

#### Reasoning Gaps
- [Gap in logic with impact]
- [Gap in logic with impact]

#### Unsupported Claims
- [Claim + suggested support]
- [Claim + suggested support]

### 1.3 Logos Review

**Argument Clarity**: [Assessment]
**Evidence Quality**: [Assessment]
**Persuasive Strength**: [Assessment on scale]

#### Recommendations to Enhance Logical Impact
- [Specific recommendation]
- [Specific recommendation]

### 1.4 Pathos Review

**Current Emotional Tone**: [Description]
**Audience Connection**: [Assessment]
**Engagement Level**: [Assessment]

#### Recommendations to Increase Resonance
- [Specific recommendation]
- [Specific recommendation]

### 1.5 Ethos Review

**Perceived Expertise**: [Assessment]
**Trustworthiness Signals Present**:
- [Signal present]
- [Signal present]

**Trustworthiness Signals Missing**:
- [Signal missing]
- [Signal missing]

**Authority Assessment**: [Assessment]

#### Credibility Recommendations
- [Specific recommendation]
- [Specific recommendation]

---

## 2. Reinforcement Phase

### Logic and Coherence Improvements

#### Resolved Contradictions
1. [Contradiction] → [Resolution]
2. [Contradiction] → [Resolution]

#### Filled Reasoning Gaps
- [Gap description]: [Solution]
- [Gap description]: [Solution]

#### Supported Unsupported Claims
- [Claim]: [Support added]
- [Claim]: [Support added]

#### Strengthened Transitions
- [Between X and Y]: [Improvement made]
- [Between Y and Z]: [Improvement made]

---

## 3. Risk Analysis Phase

### 3.1 Blind Spots

#### Hidden Assumptions
- [Assumption]: [Impact if unchallenged]
- [Assumption]: [Impact if unchallenged]

#### Overlooked Perspectives
- [Perspective]: [Relevance to audience/credibility]
- [Perspective]: [Relevance to audience/credibility]

#### Potential Biases
- [Bias type]: [Specific manifestation in content]
- [Bias type]: [Specific manifestation in content]

#### Mitigation Strategies
- [Specific action to address]
- [Specific action to address]

### 3.2 Shatter Points

#### Critical Vulnerabilities by Severity

**HIGH SEVERITY** (Must address before publication/presentation)
- [Vulnerability]: [Why critical] → [Prevention measure]
- [Vulnerability]: [Why critical] → [Prevention measure]

**MEDIUM SEVERITY** (Should address for robustness)
- [Vulnerability]: [Why important] → [Prevention measure]
- [Vulnerability]: [Why important] → [Prevention measure]

**LOW SEVERITY** (Nice to address if resources allow)
- [Vulnerability]: [Why relevant] → [Prevention measure]

#### Potential Attack Vectors
[How critics or challengers might exploit identified weaknesses]

#### Contingency Preparations
[If shatter point is exposed: recommended response or alternative framing]

---

## 4. Growth Phase

### 4.1 Bloom: Emergent Insights

#### Emergent Themes
[Patterns noticed across evaluation phases]

#### Expansion Opportunities
1. [New direction with development potential]
2. [New direction with development potential]
3. [New direction with development potential]

#### Novel Angles and Unexpected Connections
- [Unexpected perspective or application]
- [Cross-domain connection]

---

### 4.2 Evolve: Revised Content

[Full revised content incorporating all improvements, or summary of revisions 
if full revision provided separately]

#### Revision Summary
- [Major change made and rationale]
- [Major change made and rationale]

#### Strength Improvements
- **Before**: [Original weakness] → **After**: [Improvement]
- **Before**: [Original weakness] → **After**: [Improvement]

#### Risk Mitigations Applied
- [Which vulnerability was addressed and how]
- [Which blind spot was addressed and how]

---

## 5. Final Recommendations

### Next Steps
1. [Action item with priority]
2. [Action item with priority]
3. [Action item with priority]

### Resources for Implementation
- [Reference or template if helpful]
- [Tool or methodology suggestion]

### For Second Pass Evaluation
[If iterating: specific focus areas for next evaluation phase]

---

## Appendix

### A. Evaluation Methodology
[Brief description of framework and phases applied]

### B. Audience/Context Notes
[If provided: audience details, success criteria, constraints]

### C. Detailed Examples
[If complex: detailed examples of recommendations in context]

```

---

## Structured Checklist Template

Use this format for tracking implementation, agile workflows, and team coordination.

```markdown
# Evaluation Checklist: [Content Title]

**Date**: [Date]  
**Status**: [Draft / In Progress / Revision Complete]  
**Implementation Lead**: [If applicable]

---

## CRITIQUE PHASE
- [ ] Identify all major strengths (minimum 3)
- [ ] Identify all major weaknesses (minimum 3)
- [ ] Rank priority improvement areas (3-5)

**Strengths Identified**: _____ / _____  
**Weaknesses Identified**: _____ / _____  
**Priority Areas**: _____ / _____

---

## LOGIC CHECK PHASE
- [ ] Scan for contradictions (mark locations)
- [ ] Identify reasoning gaps (list and explain)
- [ ] Locate unsupported claims (with specificity)
- [ ] Flag incoherent transitions

**Contradictions Found**: [ ] 0  [ ] 1-2  [ ] 3+  
**Reasoning Gaps**: [ ] None  [ ] Minor  [ ] Significant  
**Unsupported Claims**: [ ] 0  [ ] 1-2  [ ] 3+  

---

## LOGOS REVIEW PHASE
**Argument Clarity**: [ ] Excellent  [ ] Good  [ ] Fair  [ ] Needs Work  
**Evidence Quality**: [ ] Strong  [ ] Adequate  [ ] Weak  [ ] Missing  
**Persuasive Strength**: ☐ 9-10  ☐ 7-8  ☐ 5-6  ☐ 3-4  ☐ 1-2  

**Action Items**:
- [ ] Add quantification to claims
- [ ] Include supporting research
- [ ] Strengthen evidence with [specific source]
- [ ] Clarify argument structure
- [ ] Other: _________________

---

## PATHOS REVIEW PHASE
**Emotional Resonance**: [ ] Strong  [ ] Adequate  [ ] Weak  [ ] Missing  
**Audience Connection**: [ ] Excellent  [ ] Good  [ ] Fair  [ ] Poor  
**Engagement Level**: ☐ Compelling  ☐ Adequate  ☐ Needs Work  

**Action Items**:
- [ ] Add narrative/anecdote
- [ ] Adjust tone (from _____ to _____)
- [ ] Include audience-relevant examples
- [ ] Strengthen emotional throughline
- [ ] Other: _________________

---

## ETHOS REVIEW PHASE
**Perceived Expertise**: [ ] High  [ ] Adequate  [ ] Low  
**Trustworthiness Signals**: [ ] Present  [ ] Partial  [ ] Missing  
**Authority Level**: [ ] Strong  [ ] Adequate  [ ] Weak  

**Credibility Gaps**:
- [ ] No author credentials
- [ ] Missing source citations
- [ ] No external validation
- [ ] Lacks acknowledgment of limitations
- [ ] Other: _________________

**Action Items**:
- [ ] Add author/team credentials
- [ ] Include authoritative sources
- [ ] Reference standards or research
- [ ] Add "Limitations" section
- [ ] Other: _________________

---

## REINFORCEMENT PHASE
**Contradictions Resolved**: [ ] All  [ ] Most  [ ] Some  [ ] None  
**Gaps Filled**: [ ] Complete  [ ] Adequate  [ ] Partial  
**Coherence Improved**: [ ] Significantly  [ ] Moderately  [ ] Minimally  

**Resolved**:
- [ ] Contradiction 1 (specific)
- [ ] Contradiction 2 (specific)
- [ ] Gap 1 (specific)
- [ ] Gap 2 (specific)

**Verification**:
- [ ] Revised sections read naturally
- [ ] No new contradictions introduced
- [ ] Transitions flow logically
- [ ] Original meaning preserved

---

## BLIND SPOTS PHASE
**Hidden Assumptions Identified**: [ ] None  [ ] 1-2  [ ] 3+  
**Overlooked Perspectives**: [ ] None  [ ] 1-2  [ ] 3+  
**Potential Biases**: [ ] None  [ ] Minor  [ ] Significant  

**Mitigation Actions**:
- [ ] Add context/background for assumption X
- [ ] Include perspective from [stakeholder group]
- [ ] Address bias: [specific bias] by [method]
- [ ] Expand audience representation
- [ ] Other: _________________

---

## SHATTER POINTS PHASE
**Critical Vulnerabilities**: [ ] None  [ ] 1-2  [ ] 3+  
**Vulnerability Severity**: ☐ High  ☐ Medium  ☐ Low  

**HIGH SEVERITY** (Must Fix):
- [ ] Vulnerability: _____________ → Solution: _____________
- [ ] Vulnerability: _____________ → Solution: _____________

**MEDIUM SEVERITY** (Should Fix):
- [ ] Vulnerability: _____________ → Solution: _____________
- [ ] Vulnerability: _____________ → Solution: _____________

**Preventive Measures Applied**:
- [ ] Added supporting evidence
- [ ] Included qualifying language
- [ ] Added contingency plan
- [ ] Reframed vulnerable claim
- [ ] Other: _________________

---

## BLOOM PHASE
**Emergent Insights Generated**: _____ new directions / opportunities  
**Expansion Potential**: [ ] High  [ ] Moderate  [ ] Low  

**Identified Opportunities**:
- [ ] Opportunity 1: ________________________
- [ ] Opportunity 2: ________________________
- [ ] Opportunity 3: ________________________

**Cross-Domain Connections**:
- [ ] Connection to [domain]: ________________________
- [ ] Connection to [domain]: ________________________

---

## EVOLVE PHASE
**Revision Status**: [ ] Not Started  [ ] In Progress  [ ] Complete  
**Quality Verification**: [ ] Passed  [ ] Needs Adjustment  

**Changes Integrated**:
- [ ] All Critique recommendations
- [ ] All Logic Check fixes
- [ ] All Logos enhancements
- [ ] All Pathos improvements
- [ ] All Ethos credibility additions
- [ ] All blind spot mitigations
- [ ] All shatter point preventions
- [ ] Key bloom insights incorporated

**Final Verification**:
- [ ] Original objectives met
- [ ] Internal coherence verified
- [ ] Audience appropriateness confirmed
- [ ] No new issues introduced
- [ ] Ready for [next step: publication/presentation/implementation]

---

## SIGN-OFF

**Evaluation Completed By**: _________________  
**Date Completed**: _________________  
**Ready for Next Phase**: [ ] Yes  [ ] With Revisions  [ ] Needs Major Work  

**Notes for Next Iteration**:
- _____________________
- _____________________

```

---

## Inline Revisions Template

Use this format for direct editing workflow and transparent change documentation.

```
[ORIGINAL TEXT]
→ [SUGGESTED REVISION]
{REASONING}: [Brief explanation of why change improves content]
[ALTERNATIVE]: [Optional alternative phrasing if multiple options valid]

---

EXAMPLE FORMAT:

ORIGINAL:
"The results show a significant improvement in participant satisfaction, with 
most respondents reporting positive experiences."

SUGGESTED REVISION:
"Participant satisfaction improved significantly, with 78% of respondents 
reporting positive experiences compared to 45% in control group."

REASONING: Original uses vague quantifier ("most") and lacks comparison point. 
Revision adds specific metrics (78%, control comparison) which strengthens 
Logos appeal and improves persuasiveness. Supports "significant" claim with data.

ALTERNATIVE: 
"Post-intervention, 78% of treatment participants (n=145) reported satisfaction 
compared to 45% of controls (n=152), representing a 33 percentage point improvement 
(χ² = X.XX, p < .001)." [More technical version for academic audience]

---

STRUCTURE FOR LONGER REVISIONS:

ORIGINAL PASSAGE:
[Full paragraph or section needing revision]

SUGGESTED REVISION:
[Revised version with major changes indicated]

REASONING:
1. [Issue with original]
   → [How revision addresses this]
2. [Issue with original]
   → [How revision addresses this]

RATIONALE FOR APPROACH:
[Overall strategic improvement made by this revision - which phase/principle does it serve?]

OPTIONAL - ALTERNATIVES:
Version A: [Alternative 1 with context]
Version B: [Alternative 2 with context]
→ Recommend Version [X] because [reasoning]

---

EXAMPLE - LONGER PASSAGE:

ORIGINAL PASSAGE:
"The study was conducted over six months with participants from multiple 
backgrounds. Various measures were used to assess outcomes. Results showed 
improvement across different domains. Overall, the findings suggest that the 
intervention is effective."

SUGGESTED REVISION:
"From January through June 2024, we recruited 234 participants (45% women, 
62% age 25-44, 38% with prior [relevant experience]) and assessed outcomes 
using three validated instruments: [List measures]. 

Across all domains measured—learning gains, retention, and application—
participants showed significant improvement: 73% achieved proficiency 
(pre-intervention: 34%), retention at 6-month follow-up averaged 82%, and 
67% reported applying new skills professionally within 3 months.

These findings indicate the intervention successfully improves both immediate 
learning and long-term application."

REASONING:
1. Vague timeline → Specific dates provided
   Reason: Establishes credibility, allows verification (Ethos)

2. "Multiple backgrounds" → Specific demographics with percentages
   Reason: Makes participant diversity concrete, allows assessment of 
   representativeness (Logos, Blind Spots)

3. "Various measures" → Named, validated instruments listed
   Reason: Demonstrates rigor and allows critical evaluation (Logos, Ethos)

4. "Improvement across different domains" → Specific metrics with percentages
   Reason: Concrete data far more persuasive than vague claim (Logos)

5. Vague conclusion → Specific claim tied to data
   Reason: Supports claim with evidence, reduces gap between data and interpretation 
   (Logic Check, Logos)

RATIONALE FOR OVERALL APPROACH:
This revision strengthens Logos (concrete metrics, rigor), Ethos (specific 
methodology, accountability), and Logic Check (claims clearly supported). 
Addresses blind spot of reader's inability to assess study quality. Removes 
space between data and interpretation, improving both credibility and 
persuasiveness.

ALTERNATIVES:
Version A (More technical, for academic journal):
[Include statistical tests and effect sizes]

Version B (More narrative, for public audience):
[Lead with human impact, bury specific metrics in less prominent position]

RECOMMENDATION: 
Use suggested version for academic publication; adapt Version B if communicating 
to non-expert audience.

```

---

## Format Selection Guide

**Choose Markdown Report when**:
- Creating formal documentation
- Sharing with multiple stakeholders
- Need comprehensive record for future reference
- Content is complex and requires detailed explanation
- Publishing or archiving evaluation for long-term use

**Choose Structured Checklist when**:
- Tracking implementation progress
- Working with teams across time/location
- Need quick status updates
- Multiple iterations planned
- Agile or iterative workflow
- Want clear action items and responsibility assignment

**Choose Inline Revisions when**:
- Direct editing is primary deliverable
- Author wants transparent change rationale
- Content will be integrated into original document
- Need to show "before/after" side-by-side
- Collaborative editing environment
- Author prefers to see changes in context

---

## Hybrid Approaches

Many workflows benefit from combining formats:

1. **Initial Assessment** (Autonomous): Provide Markdown Report
2. **Implementation Tracking**: Use Structured Checklist
3. **Content Revision**: Deliver Inline Revisions
4. **Final Verification**: Return to Markdown Report summary

Or:

1. **Interactive Assessment**: Use Checklist for each phase
2. **Comprehensive Documentation**: Summarize in Markdown Report
3. **Author Edits**: Provide Inline Revisions for specific passages

Adapt combination based on content type, audience, and workflow requirements.
```

---

## Customization Tips

- **For academic work**: Emphasize methodology and evidence quality in reports
- **For creative work**: Highlight pathos, emotional impact, and growth potential
- **For business/proposals**: Prioritize feasibility, risk, and credibility signals
- **For collaborative teams**: Use checklist format for clear responsibility and tracking
- **For iterative development**: Use inline revisions + checklist combination
