# Phase Prompts and Structures

Detailed prompts, output structures, and example findings for each evaluation phase.

## Evaluation Phase

### Critique

**Objective**: Provide comprehensive assessment of strengths and weaknesses

**Prompt Structure**:
```
Evaluate this content thoroughly. Identify its key strengths and weaknesses. 
Highlight which parts are effective and which need improvement, providing 
specific reasons for your assessments.
```

**Output Structure**:
```
## Strengths
- [Specific strength with reasoning]
- [Specific strength with reasoning]

## Weaknesses
- [Specific weakness with reasoning]
- [Specific weakness with reasoning]

## Priority Areas for Improvement
1. [Highest priority improvement opportunity]
2. [Secondary improvement opportunity]
3. [Tertiary improvement opportunity]
```

**Example Output** (Research Paper Critique):
```
## Strengths
- Clear problem statement in introduction establishes relevance and scope
- Methodology section includes sufficient detail for reproducibility
- Results are presented systematically with supporting visuals

## Weaknesses
- Discussion section lacks engagement with recent literature (post-2022)
- Conclusion overgeneralizes findings beyond study scope
- Some claims in abstract are not directly supported by results section

## Priority Areas
1. Expand literature review and discussion with recent publications
2. Qualify conclusion statements to match actual findings
3. Verify abstract claims against results
```

---

### Logic Check

**Objective**: Ensure internal consistency and identify reasoning gaps

**Prompt Structure**:
```
Examine this content for logical consistency. Identify any contradictions, 
gaps in reasoning, unsupported claims, or logical leaps. Suggest how to 
strengthen coherence and fill gaps.
```

**Output Structure**:
```
## Contradictions
- [Contradiction with specific locations]
- [Contradiction with specific locations]

## Reasoning Gaps
- [Gap in logic with explanation]
- [Gap in logic with explanation]

## Unsupported Claims
- [Claim lacking support with suggested support]
- [Claim lacking support with suggested support]

## Coherence Recommendations
- [Specific recommendation for strengthening flow]
- [Specific recommendation for strengthening transitions]
```

**Example Output** (Proposal Logic Check):
```
## Contradictions
- Page 3 claims "minimal resources required" but budget section requests 
  significant staffing; clarify resource scope

## Reasoning Gaps
- Timeline jumps from Phase 2 completion to Phase 4 launch; Phase 3 unclear
- Connection between proposed intervention and stated outcomes not explicit

## Unsupported Claims
- "Industry-proven approach" - provide specific precedents or references
- "95% success rate" - define success criteria and cite source

## Recommendations
- Clarify resource definition (personnel vs. capital vs. operational costs)
- Add explicit Phase 3 deliverables and transition criteria
- Cite 2-3 case studies demonstrating similar interventions
```

---

### Logos Review

**Objective**: Assess rational and factual appeal of arguments

**Prompt Structure**:
```
Assess the rational and factual appeal of this content. Are the arguments 
clear, well-supported with evidence, and persuasive? Suggest ways to enhance 
logical impact and strengthen factual foundation.
```

**Output Structure**:
```
## Argument Clarity
[Assessment of how clearly arguments are stated]

## Evidence Quality
[Assessment of supporting evidence: sufficient, relevant, authoritative]

## Persuasive Strength
[Assessment of how compelling the case is]

## Enhancement Recommendations
- [Specific recommendation for strengthening argument]
- [Recommendation for adding or improving evidence]
- [Recommendation for structural improvement]
```

**Example Output** (Policy Document):
```
## Argument Clarity
- Main argument is clear: "Current system creates inefficiency in X"
- Supporting arguments are stated explicitly
- Some secondary claims could be more specific (e.g., "significantly higher" 
  without quantification)

## Evidence Quality
- Primary evidence comes from single organization report (2020)
- Missing: comparative data from similar jurisdictions
- Missing: recent peer-reviewed research on this problem space
- Recommendations have anecdotal support but no empirical basis

## Persuasive Strength
- Problem statement effectively motivates reader concern (7/10)
- Solution rationale is logical but not empirically grounded (5/10)
- Implementation plan lacks detail to assess feasibility (4/10)

## Recommendations
1. Add quantification to "significantly" claims (use percentage increases, 
   cost metrics, time measurements)
2. Include 2-3 peer-reviewed studies on similar policy interventions
3. Reference comparable jurisdictions and their outcomes
4. Strengthen solution justification with pilot data or precedent studies
```

---

### Pathos Review

**Objective**: Evaluate emotional resonance and audience connection

**Prompt Structure**:
```
Analyze the emotional tone and resonance of this content. Does it create 
an emotional connection with its intended audience? Assess engagement level 
and recommend adjustments to increase relevance and impact.
```

**Output Structure**:
```
## Current Emotional Tone
[Description of dominant emotional qualities]

## Audience Connection
[Assessment of how well content resonates with target audience]

## Engagement Level
[Assessment of how compelling/compelling the content is]

## Recommendations for Increased Resonance
- [Specific recommendation for emotional enhancement]
- [Recommendation for audience alignment]
- [Recommendation for engagement increase]
```

**Example Output** (Marketing Copy):
```
## Current Emotional Tone
- Professional and authoritative
- Somewhat detached/clinical in language
- Lacks urgency or excitement

## Audience Connection
- Content speaks to rational benefits but not aspirational values
- Target audience (young professionals) would resonate more with 
  identity/community aspects
- No personal voice or relatable narrative

## Engagement Level
- Information is comprehensive but presentation is dense (5/10)
- Visual hierarchy could better guide reader attention
- Missing "why this matters to you" framing

## Recommendations
1. Add brief customer story or use case showing real-world impact
2. Reframe benefits in terms of values and identity ("You're the kind of 
   person who...") not just features
3. Vary sentence length and structure to improve readability and pacing
4. Include specific emotional trigger words without overselling 
   (confidence, possibility, growth)
```

---

### Ethos Review

**Objective**: Examine credibility, authority, and trustworthiness

**Prompt Structure**:
```
Evaluate the credibility and authority of this content. Does it demonstrate 
expertise and trustworthiness? Assess what signals of reliability are present 
or missing, and suggest ways to reinforce authority and professional tone.
```

**Output Structure**:
```
## Perceived Expertise
[Assessment of how knowledgeable the author/content appears]

## Trustworthiness Signals
Present:
- [Signal reinforcing credibility]
- [Signal reinforcing credibility]

Missing:
- [Missing signal that would strengthen credibility]
- [Missing signal that would strengthen credibility]

## Authority Assessment
[Assessment of positioning and influence]

## Credibility Recommendations
- [Specific recommendation for strengthening authority]
- [Recommendation for adding credentials/sources]
- [Recommendation for improving professional tone]
```

**Example Output** (Technical Documentation):
```
## Perceived Expertise
- Content is technically accurate and thorough
- Terminology is used correctly
- Would benefit from visible qualification markers (author background)

## Trustworthiness Signals
Present:
- Comprehensive technical detail suggests insider knowledge
- References to standards (ISO, RFC) add authority
- Version control and update dates establish maintenance

Missing:
- No author credentials or company authority markers
- No acknowledgment of limitations or edge cases
- No external validation or citations to research

## Authority Assessment
- Positioned as technical reference (good for internal audiences)
- Lacks external credibility markers for unknown readers
- Could be strengthened with expert endorsement or certification

## Recommendations
1. Add author/team credentials and relevant experience in header
2. Include "Known Limitations" section showing thoughtful analysis
3. Cite relevant published standards or research (IEEE, ACM papers)
4. Link to third-party case studies or testimonials using this approach
5. Include security/audit certifications if applicable
```

---

## Reinforcement Phase

### Logic Synthesis

**Objective**: Resolve contradictions and reinforce coherence

**Process**:
1. Take contradictions identified in Logic Check
2. Rewrite affected sections to resolve inconsistency
3. Verify changes against overall argument structure
4. Strengthen transitional logic between sections

**Output Structure**:
```
## Contradiction Resolution
[Section name]: [Original contradiction] → [Revised approach]

## Gap Filling
[Gap description]: [Content added or restructured]

## Coherence Improvements
- [Transition strengthened between X and Y]
- [Terminology harmonized across sections]
- [Logical sequence clarified]
```

---

## Risk Analysis Phase

### Blind Spots

**Objective**: Reveal overlooked areas and hidden assumptions

**Prompt Structure**:
```
Identify any areas in this content that may be overlooked, biased, based on 
hidden assumptions, or that might not account for alternative perspectives. 
Consider: What is this content assuming about the reader? What contextual 
factors might not be addressed? Where might implicit bias appear? Provide 
suggestions to address these gaps.
```

**Output Structure**:
```
## Hidden Assumptions
- [Assumption with explanation of impact]
- [Assumption with explanation of impact]

## Overlooked Perspectives
- [Perspective missing from analysis]
- [Perspective missing from analysis]

## Potential Biases
- [Bias type with specific location]
- [Bias type with specific location]

## Mitigation Strategies
- [Specific action to address assumption]
- [Specific action to include perspective]
- [Specific action to counteract bias]
```

**Example Output** (Research Proposal):
```
## Hidden Assumptions
- Assumes all participants have prior familiarity with topic (impacts 
  participant recruitment and retention)
- Assumes single definition of "success" across diverse stakeholders 
  (impacts validity of outcomes)

## Overlooked Perspectives
- No consideration of participant burden or accessibility needs
- Missing stakeholder voices (subject matter experts not in research team)
- Cultural or regional context not addressed

## Potential Biases
- Selection bias: Recruiting from single institution limits generalizability
- Confirmation bias: Research design may favor hypothesis confirmation
- Demographic bias: No discussion of participant diversity or representation

## Mitigations
1. Add brief background section in protocol materials
2. Include stakeholder advisory board in design phase
3. Document accessibility accommodations and participant burden analysis
4. Multi-site recruitment strategy or comparison groups
5. Pre-register hypothesis and analysis plan
```

---

### Shatter Points

**Objective**: Identify critical vulnerabilities

**Prompt Structure**:
```
Analyze this content for potential vulnerabilities, weak points, or areas 
where the argument could fail under scrutiny or criticism. Consider: Where 
might someone attack this? What assumptions could be challenged? Where is 
evidence thinnest? Recommend preventive measures and contingency preparations.
```

**Output Structure**:
```
## Critical Vulnerabilities
- [Vulnerability with severity level and reasoning]
- [Vulnerability with severity level and reasoning]

## Potential Attack Vectors
[How critics or challengers might exploit weakness]

## Preventive Measures
- [Specific action to strengthen vulnerable area]
- [Specific action to preempt criticism]

## Contingency Preparations
- [What to do if this weakness is exposed]
- [Alternative framing or evidence]
```

**Example Output** (Business Plan):
```
## Critical Vulnerabilities
- Revenue model unproven in target market (HIGH SEVERITY)
- Competitive analysis only mentions 2 competitors; market landscape unclear 
  (HIGH SEVERITY)
- No contingency for key person departure (MEDIUM SEVERITY)
- Customer acquisition cost projections lack supporting data (MEDIUM SEVERITY)

## Potential Attack Vectors
- Investors will ask "Why will customers choose you over X?" (competitive 
  differentiation)
- "What happens to this plan if founder leaves?" (key person risk)
- "How did you calculate CAC?" (financial modeling credibility)

## Preventive Measures
1. Commission market research or pilot program showing revenue model validation
2. Expand competitive analysis to 8-10 key competitors with feature matrices
3. Detail succession plan and cross-training for key roles
4. Model CAC based on comparable company data with transparent assumptions
5. Add sensitivity analysis showing how changes in CAC impact profitability

## Contingency Preparations
1. If revenue model questioned: Have pilot data or comparable company metrics 
   ready
2. If competitive advantage questioned: Articulate clear differentiation tied 
   to customer needs
3. If key person questioned: Present strong management team credentials
```

---

## Growth Phase

### Bloom (Emergent Insights)

**Objective**: Generate new directions and opportunities

**Prompt Structure**:
```
Based on all the evaluation, analysis, and refinement work above, what new 
insights emerge? What patterns do you notice across the feedback? What new 
directions, expansion opportunities, or unexpected connections could enhance 
or amplify this work? Generate 3-5 innovative ideas for development.
```

**Output Structure**:
```
## Emergent Themes
[Patterns that appeared across evaluation phases]

## Expansion Opportunities
- [New direction with development potential]
- [New direction with development potential]

## Novel Angles
- [Unexpected perspective or approach]
- [Unexpected perspective or approach]

## Cross-Domain Connections
- [Connection to adjacent field or discipline]
- [Connection to adjacent field or discipline]
```

**Example Output** (Academic Paper):
```
## Emergent Themes
- Central finding (X) has implications beyond stated scope
- Methodology could be applied to adjacent problems
- Stakeholder perspectives (from blind spots analysis) suggest new research 
  questions

## Expansion Opportunities
1. Case studies applying findings to real-world scenarios
2. Comparative analysis across different contexts/populations
3. Interactive visualization of findings for public audience
4. Policy brief distilling implications for practitioners

## Novel Angles
- Unexpected tension between findings and prior literature suggests 
  generational or contextual shift
- Method could be modified to address limitations in adjacent field

## Cross-Domain Connections
- Findings parallel work in related discipline (specify)
- Could inform practice in X, Y, or Z professional contexts
```

---

### Evolve (Iterative Refinement)

**Objective**: Produce strengthened final version

**Process**:
1. Integrate all evaluation findings systematically
2. Incorporate reinforcement improvements
3. Address risk analysis recommendations
4. Implement growth insights where applicable
5. Verify coherence and completion of original objectives

**Output Structure**:
```
## Revision Summary
[Overview of changes made and why]

## Strength Improvements
- [Before/After: Specific improvement made]
- [Before/After: Specific improvement made]

## Risk Mitigations Applied
- [Which vulnerability was addressed and how]
- [Which blind spot was addressed and how]

## Final Product
[Revised content in requested format]

## Quality Verification
- [Verification that original objectives are met]
- [Verification of internal coherence]
- [Verification of audience appropriateness]
```

---

## Content-Type Specific Considerations

### Research Papers
- **Logos emphasis**: Data presentation, methodology soundness, statistical rigor
- **Ethos emphasis**: Literature positioning, citation practices, credibility
- **Blind spots focus**: Methodological limitations, generalizability bounds, researcher bias
- **Shatter points focus**: Statistical validity, reproducibility, scope claims

### Creative Work (Fiction, Poetry, Visual Art)
- **Pathos emphasis**: Emotional impact, resonance with audience values
- **Logos emphasis**: Internal consistency of world/logic, conceptual coherence
- **Blind spots focus**: Audience assumptions, representation considerations
- **Bloom emphasis**: Unexpected directions, cross-disciplinary applications

### Professional Proposals (Business, Grant, Policy)
- **Logos emphasis**: Argument structure, evidence for claims, feasibility
- **Ethos emphasis**: Credibility of proposer, track record, authority
- **Shatter points focus**: Competitive vulnerabilities, implementation risks, key assumptions
- **Pathos emphasis**: Vision and aspiration, stakeholder buy-in

### Technical Documentation
- **Logos emphasis**: Clarity, completeness, accuracy of technical content
- **Blind spots focus**: Assumed knowledge level, accessibility for different skill levels
- **Ethos emphasis**: Authority and reliability, version control, maintenance
- **Pathos emphasis**: Engagement and usability, voice and tone

### Presentations/Talks
- **Pathos emphasis**: Audience engagement, narrative arc, emotional pacing
- **Logos emphasis**: Argument flow, visual support for claims
- **Ethos emphasis**: Speaker credibility, Q&A readiness
- **Shatter points focus**: Common objections, data visualization risks
